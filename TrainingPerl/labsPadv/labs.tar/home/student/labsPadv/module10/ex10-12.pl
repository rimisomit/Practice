#! /usr/bin/perl
#ex10-12
use POSIX;
$filename = "file.txt";
$descrip = POSIX::open($filename, POSIX::O_RDONLY);
($dev, $ino, $undeff, $nlink, $uid, $gid, $rdev, $size, $atime,
$mtime, $ctime, $blksize, $blocks) = POSIX::fstat($descrip);
print "$filename\n" .  
      "'dev=' $dev\n" .
	"'ino=' $ino\n" .
	"'nlink=' $nlink\n" .
	"'uid=' $uid\n" .
	"'gid=' $gid\n".
	"'rdev=' $rdev\n".
	"'size=' $size";



