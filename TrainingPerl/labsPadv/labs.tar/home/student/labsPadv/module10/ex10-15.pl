#! /usr/bin/perl
# usage perl ex10-15 file1 file2 file3 ...
#ex10-15
while (<>) {
	print;
	if (eof()) {
		print "And that is it!"; }
}




