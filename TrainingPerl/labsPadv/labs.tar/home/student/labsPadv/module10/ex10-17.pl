#! /usr/bin/perl
#ex10-17
print join("\n", glob ('*'));





