#! /usr/bin/perl
#ex10-16
while (<>) {
	print;
	if(eof) {
		print "-" x 30; }
	if(eof()) {
		print "And that is it!"; }
}




