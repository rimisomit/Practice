#! /usr/bin/perl
#ex10-7
$input = readline (*STDIN);
print $input;


