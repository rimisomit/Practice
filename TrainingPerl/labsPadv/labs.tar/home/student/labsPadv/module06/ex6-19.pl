#! /usr/bin/perl 
#ex6-19
$arrayreference = [[1, 2, 3], [4, 5, 6]];
print $arrayreference->[1][1];
