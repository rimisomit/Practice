#! /usr/bin/perl 
#ex6-22
$variable1 = 5;
$scalarref = \$variable1;
print (ref $scalarref);
