#! /usr/bin/perl 
#ex6-20
$hashreference->{key} = "This is the text.";
print $hashreference->{key};
