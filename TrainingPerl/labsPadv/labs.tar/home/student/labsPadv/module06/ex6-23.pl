#! /usr/bin/perl 
#ex6-23
$variable1 = 0;
$variablename = "variable1";
$$variablename = 5;
print "$variable1\n";
