#! /usr/bin/perl 
#ex6-13
$variable1 = 5;
$scalarreference = *variable1{SCALAR};
print $$scalarreference;
