#! /usr/bin/perl -w
#ex6-2
$variable1 = 5;
$reference = \$variable1;
print $reference;

