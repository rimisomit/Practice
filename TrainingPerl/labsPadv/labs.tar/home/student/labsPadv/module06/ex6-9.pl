#! /usr/bin/perl 
#ex6-9
print "@{[uc(hello)]} there. \n";
