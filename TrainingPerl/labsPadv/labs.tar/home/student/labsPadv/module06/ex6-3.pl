#! /usr/bin/perl 
#ex6-3
$variable1 = 5;
$variablename = "variable1";
print "$$variablename\n";

