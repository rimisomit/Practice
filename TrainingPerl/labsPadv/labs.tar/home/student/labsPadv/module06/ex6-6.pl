#! /usr/bin/perl 
#ex6-6
$reference = \\\\"Hello!";
print $$$$$reference;

