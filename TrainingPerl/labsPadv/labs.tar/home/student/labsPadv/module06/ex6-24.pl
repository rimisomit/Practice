#! /usr/bin/perl -w
#ex6-24
$arrayref = [{first=>1, second=>2}, "Hello", "there"];
print $arrayref->{first} ." ". $arrayref->{second};
