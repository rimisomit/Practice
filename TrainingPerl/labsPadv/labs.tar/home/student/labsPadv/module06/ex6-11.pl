#! /usr/bin/perl 
#ex6-11
$codereference = sub {print "Hello!\n"};
&$codereference;
