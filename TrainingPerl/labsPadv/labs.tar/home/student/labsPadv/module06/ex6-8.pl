#! /usr/bin/perl 
#ex6-8
$arrayreference = [1, 2, 3];
print $$arrayreference[0];
