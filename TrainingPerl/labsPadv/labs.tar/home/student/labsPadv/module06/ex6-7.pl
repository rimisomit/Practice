#! /usr/bin/perl 
#ex6-7
$$reference = 5;
print "$$reference\n";
