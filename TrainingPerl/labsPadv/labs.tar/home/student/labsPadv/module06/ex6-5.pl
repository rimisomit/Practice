#! /usr/bin/perl 
#ex6-5
$arrayreference = [1, 2, 3];
print $$arrayreference[0];

