#! /usr/bin/perl 
package Module1;
BEGIN {
	use Exporter ();
	@ISA = 'Exporter';
	@EXPORT = '&subroutine1'; }

sub subroutine1 { print "Hello!\n"; }
return 1;

END { }

