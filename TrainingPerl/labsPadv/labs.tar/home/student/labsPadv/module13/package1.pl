package package1;
BEGIN { }
sub subroutine1 { print "Hello!\n"; }
return 1;
END { }
