package package1111;
BEGIN { }
	sub subroutine1 { print __PACKAGE__; }
return 1;
END { }
