#! /usr/bin/perl 
#ex13-1
#
require 'package1.pl';
package1::subroutine1();
