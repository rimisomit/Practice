#! /usr/bin/perl
#ex13-6/pl
require 'file1.pl';
require 'file2.pl';
package1::hello();
package1::hello2();
