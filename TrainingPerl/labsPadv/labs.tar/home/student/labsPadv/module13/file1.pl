package package1;
BEGIN { }
sub hello { print "Hello!\n"; }
return 1;
END { }
