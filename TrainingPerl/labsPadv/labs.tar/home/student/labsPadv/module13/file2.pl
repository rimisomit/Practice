package package1;
BEGIN { }
sub hello2 { print "Hello again!\n"; }
return 1;
END { }

