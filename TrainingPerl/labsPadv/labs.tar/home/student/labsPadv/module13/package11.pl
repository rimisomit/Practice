package package11;

sub BEGIN
{
	$text = "Hello! \n";
}

sub subroutine1
{
	print $text;
}

return 1;
