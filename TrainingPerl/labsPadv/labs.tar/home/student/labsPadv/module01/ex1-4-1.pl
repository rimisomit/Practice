#! /usr/bin/perl
#ex1-4-1
*MAXFILES = \100;
print "$MAXFILES\n";
$MAXFILES = 101;
