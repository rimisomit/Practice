#! /usr/bin/perl -w
#ex1-29
($a, $b) = map (lc, A, B);
print $a, $b;







