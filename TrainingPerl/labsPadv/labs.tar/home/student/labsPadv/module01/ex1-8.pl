#! /usr/bin/perl
##ex1-8
print oct 10;

