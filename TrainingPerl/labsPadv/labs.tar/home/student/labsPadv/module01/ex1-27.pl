#! /usr/bin/perl -w
#ex1-27
$a =0; $b = 0; $c = 0;
($a, $b, $c) = (1, 2);
print $a, "\n";
print $b, "\n";
print $c, "\n";






