#! /usr/bin/perl
#ex1-4

*MAXFILES = \100;
print "$MAXFILES\n";
