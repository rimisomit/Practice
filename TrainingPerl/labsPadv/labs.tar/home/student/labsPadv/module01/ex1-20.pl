#! /usr/bin/perl
#ex1-20
$uptime = `uptime`;
print $uptime





