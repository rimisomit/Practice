#! /usr/bin/perl -w
#ex1-13 - error messages
$variable1= "Hello ";
$variable2 = "there\n";
print $variable1 + $variable2;



