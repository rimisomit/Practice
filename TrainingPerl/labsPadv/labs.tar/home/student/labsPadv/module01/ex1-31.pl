#! /usr/bin/perl
#ex1-31
print join ("", H, e, l, l, o);








