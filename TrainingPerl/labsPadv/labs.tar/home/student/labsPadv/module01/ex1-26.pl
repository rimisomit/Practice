#! /usr/bin/perl
#ex1-26
($a, $b) = (1, 2, 3);
print "a=$a\n"; # expected 1
print "b=$b\n"; # expected 2





