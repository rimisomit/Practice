#! /usr/bin/perl
#ex1-24
print (1, 2, 3);




