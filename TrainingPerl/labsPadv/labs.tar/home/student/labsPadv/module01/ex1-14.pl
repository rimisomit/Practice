#! /usr/bin/perl -w
#ex1-14
$variable1= "Hello ";
$variable2 = "there\n";
print $variable1.$variable2;



