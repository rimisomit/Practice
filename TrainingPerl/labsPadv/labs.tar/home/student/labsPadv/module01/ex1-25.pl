#! /usr/bin/perl
#ex1-25
$variable1 = (a, b, c)[1];
print $variable1;




