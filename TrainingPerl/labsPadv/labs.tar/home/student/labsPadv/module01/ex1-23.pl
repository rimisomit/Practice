#! /usr/bin/perl
#ex1-23

print qq{I said, "Hello."};

print qq[I said, "Hello."];

print qq<I said, "Hello.">;





