#! /usr/bin/perl
#ex1-22
print qq/I said, "Hello."/;





