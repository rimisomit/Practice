#! /usr/bin/perl
#ex1-18
$text = "un";
print "Don't be ${text}happy."




