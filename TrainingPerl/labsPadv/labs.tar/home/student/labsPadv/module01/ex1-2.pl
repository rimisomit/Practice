#! /usr/bin/perl
#ex1-2
chop($input = 123);
print $input;
