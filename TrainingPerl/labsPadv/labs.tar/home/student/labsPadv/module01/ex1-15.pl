#! /usr/bin/perl -w
#ex1-15
print "I said, \"Hello\".";



