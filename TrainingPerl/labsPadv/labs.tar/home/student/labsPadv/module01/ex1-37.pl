#! /usr/bin/perl
#ex1-37
print "list context: ", (1, 2, 5), "\n";
print "scalar context: ", scalar (1, 2, 5), "\n"; 








