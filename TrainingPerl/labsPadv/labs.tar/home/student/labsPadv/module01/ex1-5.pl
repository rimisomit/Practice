#! /usr/bin/perl
#ex1-5
while ($input=<>) {
print $input;
}
