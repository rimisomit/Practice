#! /usr/bin/perl
#ex1-7
print sprintf "%X", 16;

