#! /usr/bin/perl -w
#ex1-28
($a, undef, $b) = (1, 2, 3);
print "a=$a\n"; # expected 1
print "b=$b\n"; # expected 3







