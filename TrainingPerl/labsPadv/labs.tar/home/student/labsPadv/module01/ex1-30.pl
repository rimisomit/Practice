#! /usr/bin/perl -w
#ex1-30
print join (":", "12", "00", "00");








