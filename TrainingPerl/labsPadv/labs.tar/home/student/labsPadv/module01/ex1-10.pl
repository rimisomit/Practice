#! /usr/bin/perl
#ex1-10
print sprintf "%.2f", 3.14159265359;


