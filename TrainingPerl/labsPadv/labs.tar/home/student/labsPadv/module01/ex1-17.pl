#! /usr/bin/perl
#ex1-17
$text = "Hello";
print 'Perl says: $text!\n';



