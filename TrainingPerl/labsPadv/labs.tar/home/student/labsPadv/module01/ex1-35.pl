#! /usr/bin/perl
##ex1-35
print reverse (1, 2, 3);








