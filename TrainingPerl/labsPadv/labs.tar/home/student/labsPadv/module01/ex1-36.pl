#! /usr/bin/perl
#ex1-36
print grep (/x/, a, b, x, d);








