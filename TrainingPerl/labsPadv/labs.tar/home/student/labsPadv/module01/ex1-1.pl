#! /usr/bin/perl
#ex1-1

print $input=123;
