#! /usr/bin/perl -w
#ex1-16
$text = "Hello";
print "Perl says: $text!\n";



