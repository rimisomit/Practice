#! /usr/bin/perl
#ex1-19
$a = "Hello";
$b = "there";
print "$a $b\n";





