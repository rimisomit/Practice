#! /usr/bin/perl
#ex1-32
print split /,/, "H,e,l,l,o";








