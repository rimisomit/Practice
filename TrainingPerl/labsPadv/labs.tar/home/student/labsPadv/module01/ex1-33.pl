#! /usr/bin/perl
#ex1-33
print sort ("c", "b", "a");









