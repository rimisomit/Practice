#! /usr/bin/perl
#ex1-21
print "${&getmessage}";

sub getmessage {
	$msg = "Hello!";
	return "msg";
};





