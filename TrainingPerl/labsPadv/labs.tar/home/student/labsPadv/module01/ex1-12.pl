#! /usr/bin/perl
#ex1-12
$variable1 = sprintf "%.2f", 3.14159265359;
$variable1 += .01;
print $variable1;



