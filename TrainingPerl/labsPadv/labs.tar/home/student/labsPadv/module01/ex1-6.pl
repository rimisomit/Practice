#! /usr/bin/perl
#ex1-6
print hex 0x1AB;
