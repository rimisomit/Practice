#! /usr/bin/perl
#ex1-9
print sprintf "%o", 16;


