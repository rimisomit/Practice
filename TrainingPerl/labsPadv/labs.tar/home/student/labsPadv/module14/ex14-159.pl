#! /usr/bin/perl -w
#ex14-159
my $a=1;
$_='a';
/(a)/;
print "$1\n";
/(b)/;
print "$1\n";

