#! /usr/bin/perl -w
#ex14-34
while ('abcd'=~/(\w)/g) { print $1 }
