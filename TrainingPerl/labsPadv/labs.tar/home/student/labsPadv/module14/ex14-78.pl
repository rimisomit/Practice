#! /usr/bin/perl -w
#ex14-78
my @a=([1,2],[3,4]);
$_="aaa$a[1][0]aaa";
print $_;
