#! /usr/bin/perl -w
#ex14-98
use strict;

$_='z';
my $a=undef;
/^$a$/;

