#! /usr/bin/perl
#ex14-5 the pattern a+?
$text=bbbaaaabbb;
print $text =~ /(a+?)/;
#print $text =~ /(a+?)/; 
