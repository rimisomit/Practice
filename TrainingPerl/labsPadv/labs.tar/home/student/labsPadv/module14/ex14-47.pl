#! /usr/bin/perl -w
#ex14-47
$_="a\n\n";
print '1' if /a\n^/;
