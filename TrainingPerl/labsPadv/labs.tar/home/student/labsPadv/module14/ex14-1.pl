#! /usr/bin/perl
#ex14-1
print ':' =~ m:[abc\:def]:;
