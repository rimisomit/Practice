#! /usr/bin/perl -w
#ex14-46
$_="a\n\n";
print '1' if m'a\n^'m;
