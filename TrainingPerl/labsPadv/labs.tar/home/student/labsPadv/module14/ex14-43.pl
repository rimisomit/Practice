#! /usr/bin/perl -w
#ex14-43
$_="a\r\nb";
print '1' if m'a\r$\n';
