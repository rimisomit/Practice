#! /usr/bin/perl -w
#ex14-62
$_='abcd';
s/z*/!/g;
print $_;
