#! /usr/bin/perl -w
#ex14-41
$_="a\r\n";
print '1' if m'a\r$\n';
