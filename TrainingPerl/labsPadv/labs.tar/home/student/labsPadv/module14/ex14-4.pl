#! /usr/bin/perl
#ex14-4 the pattern \w*a
$text=abcabcaaaaa;
print $text =~ /(\w*a)/;
#print $text =~ /(\w*a)/; 
