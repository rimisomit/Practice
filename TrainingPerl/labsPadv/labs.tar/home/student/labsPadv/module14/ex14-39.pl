#! /usr/bin/perl -w
#ex14-39
$_='abc';
my $s='c';
print '1' if /^ab$s$/;

