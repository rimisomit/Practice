#! /usr/bin/perl -w
#ex14-99
$_='a';
my $n=1;
/^(a{$n})$/;
print $1;

