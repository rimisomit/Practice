#! /usr/bin/perl -w
#ex14-135
my $re=qr/
           [a-z]+  # все буквы
         /x;
print $re;
