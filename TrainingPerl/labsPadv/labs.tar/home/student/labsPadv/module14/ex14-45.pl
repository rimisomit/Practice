#! /usr/bin/perl -w
#ex14-45
$_="a\n";
print '1' if /a\n^/m;
