#! /usr/bin/perl
#ex14-2
while (<>){
if (/stop|quit|exit|abort/i) { exit }
}


