#! /usr/bin/perl
#ex14-19
$_='abcd';

/(\w+)(\w+)/;

print "$1|$2";

