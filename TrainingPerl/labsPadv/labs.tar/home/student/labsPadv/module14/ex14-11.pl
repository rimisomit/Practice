#! /usr/bin/perl
#ex14-11
$_='aabbaa';
print s/a/c/g."\n".$_;
