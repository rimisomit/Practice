#! /usr/bin/perl -w
#ex14-40
$_='abc';
my $s='ab';
print /[$s]/g;

