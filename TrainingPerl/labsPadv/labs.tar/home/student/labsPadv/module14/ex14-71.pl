#! /usr/bin/perl -w
#ex14-71
$_='12991234';
my @a=/99\d\d/g;
print @a;
