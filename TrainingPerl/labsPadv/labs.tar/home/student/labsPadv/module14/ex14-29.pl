#! /usr/bin/perl -w
#ex14-29  $+ and $^N  diff
print "\$+=$+, \$^N=$^N" if "abc" =~ /(a(bc))/;
