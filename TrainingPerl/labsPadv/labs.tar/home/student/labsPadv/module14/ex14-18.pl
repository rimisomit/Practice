#! /usr/bin/perl
#ex14-18

$text=aaaabb;
print $text=~/(\w{1,3}?b)/;

