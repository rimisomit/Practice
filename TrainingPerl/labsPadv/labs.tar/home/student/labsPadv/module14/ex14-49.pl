#! /usr/bin/perl -w
#ex14-49
my @a='12345' =~ /\d/g;
print join ',',@a;
