#! /usr/bin/perl
#ex5-1
$value = 10;
if ($value > 10) {
	print "value is $value.\n";
} else {
	print "Value is too small. \n";
}

$value = 12;
if ($value > 10) {
	print "value is $value.\n";
} else {
	print "Value is too small.\n";
}
