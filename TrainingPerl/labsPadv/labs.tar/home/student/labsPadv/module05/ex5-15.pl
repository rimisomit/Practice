#! /usr/bin/perl -w
#ex5-15

my $count;
sub incrementcount {
	return ++$count;
};


print incrementcount . "\n";
print incrementcount . "\n";
print incrementcount . "\n";
print incrementcount . "\n";
