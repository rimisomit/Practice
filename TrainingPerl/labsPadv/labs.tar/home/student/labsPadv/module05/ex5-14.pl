#! /usr/bin/perl
#ex5-14
sub incrementcount {
	my $count;
	return ++$count;
};

print incrementcount . "\n";
print incrementcount . "\n";
print incrementcount . "\n";
print incrementcount . "\n";

