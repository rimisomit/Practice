#! /usr/bin/perl
#ex5-12
sub printem
{
	my $inner = shift @_;
	print $inner;
};

printem "Hello!\n";
print "/" . $inner;
