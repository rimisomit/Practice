#! /usr/bin/perl
#ex4-11
@array = ("Hello ", "there.\n");
foreach (@array) {print;}





