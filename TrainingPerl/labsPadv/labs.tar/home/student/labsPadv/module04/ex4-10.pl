#! /usr/bin/perl
#ex4-10
for ($line = <>; $line !~ /^q/i; $line) {
	print $line;
}




