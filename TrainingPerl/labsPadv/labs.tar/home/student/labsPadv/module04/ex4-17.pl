#! /usr/bin/perl
#ex4-17
	print $_ foreach (1, 2, 3, 4, 5, 6, 7, 8);


