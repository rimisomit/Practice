#! /usr/bin/perl
#ex4-6
$variable = 2;
if ($variable == 1) {
	print "Yes, it's one.\n";
} elsif ($variable == 2) {
	print "Yes, it's two. \n";
} elsif ($variable == 3) {
	print "Yes. it's three.\n";
} elsif ($variable == 4) {
	print "Yes, it's four.\n";
} elsif ($variable == 5) {
	print "Yes, it's five.\n";
} else {
	print "Sorry, can's match it!\n";
}

