#! /usr/bin/perl
#ex4-12
$hash{fruit} = orange;
$hash{sandwich} = clubburger;
$hash{drink} = lemonade;
foreach $key (keys %hash) {
	print $hash{$key} . "\n";
}




