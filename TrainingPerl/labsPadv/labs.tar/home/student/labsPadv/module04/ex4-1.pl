#! /usr/bin/perl
#ex4-1
$variable = 5;
if ($variable == 5) {
	print "Yes, it's five.\n";
} else {
	print "No, it's not five.\n";
}
