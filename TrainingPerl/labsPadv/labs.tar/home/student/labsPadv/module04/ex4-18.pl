#! /usr/bin/perl
#ex4-18
NUMBER: while (<>) {
	next NUMBER if /^-/;
	print;
}



