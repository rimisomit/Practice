#! /usr/bin/perl
#ex4-25
$fname = "nonexist.pl";
	open FileHandle, $fname or die "cannot open $fname\n";

