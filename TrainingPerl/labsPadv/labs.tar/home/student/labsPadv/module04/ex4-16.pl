#! /usr/bin/perl
#ex4-16
while (<>) {
	print "Too big!\n" if $_ > 100;
}

