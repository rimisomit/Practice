#! /usr/bin/perl
#ex4-22
	eval "print \"Hello\n\"";



