#! /usr/bin/perl
#ex4-9
$factorial = 1;
	for (my $ind_loop = 1; $ind_loop <= 6; $ind_loop++) {
		print $factorial *= $ind_loop , "--";
}



