#! /usr/bin/perl
#ex4-14
$loop_index = 1;
while ($loop_index <= 5) {
	print "Hello!\n";
} continue
	{ $loop_index++; }



