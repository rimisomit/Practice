#! /usr/bin/perl
#ex4-23
	eval "print \"Hello \";
	print \"there\n\"";



