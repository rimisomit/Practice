#! /usr/bin/perl
#ex4-15
$loop_index = 1;
until ($loop_index > 5) {
	print "Hello!\n";
} continue
	{ $loop_index++; }


