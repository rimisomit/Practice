#! /usr/bin/perl
#ex4-5
$variable = 6;
if ($variable == 5) {
	print "Yes, it's five.\n";
} else {
	print "No, it's not five.\n";
}
