#! /usr/bin/perl
#ex9-3
$value = 1234.56789;
printf "%.4f\n", $value;

printf "%.5f\n", $value;

printf "%6.6f\n", $value;

printf "%+.4e\n", $value;
