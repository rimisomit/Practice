#! /usr/bin/perl
#ex9-8
format STDOUT =
@>>>>>>>>>>>>>>>>>
$text
.
$text = "Hello!";
write;

