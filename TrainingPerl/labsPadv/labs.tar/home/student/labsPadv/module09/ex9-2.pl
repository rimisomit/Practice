#! /usr/bin/perl
#ex9-2
$a = "Hello"; $b = " to"; $c = " you"; $d = " from"; $e = " Perl!";
print $a, $b, $c, $d, $e;
