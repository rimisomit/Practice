#! /usr/bin/perl
#ex9-1
format STDOUT =
@<<<<<<<<<<@>>>>>>>>>>>
$text1, $text2
.
$text1 = "Hello";
$text2 = "there!";
write;	#	by def - STDOUT
