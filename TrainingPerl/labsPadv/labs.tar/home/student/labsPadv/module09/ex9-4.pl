#! /usr/bin/perl
#ex9-4
while ($input = <>)
{ print $input; }
