#! /usr/bin/perl
#ex9-7
format STDOUT =
@<<<<<<<<<<<<<@<<<<<<<<<<<@<<<<<<<<<<@<<<<
$firstname, $lastname, $ID, $extension
.
$firstname = "Cary"; $lastname = "Grant";
$ID = 1024; $extension = x456;
write;

