#! /usr/bin/perl
#ex13-3.pl
require 'packaqe1.pl';
package1::subroutine1();
