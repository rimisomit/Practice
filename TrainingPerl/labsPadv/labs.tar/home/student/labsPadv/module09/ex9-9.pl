#! /usr/bin/perl
#ex9-9
format STDOUT =
@||||||||||||||||||||
$text
.
$text = "Hello!";
write;
