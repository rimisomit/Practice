#! /usr/bin/perl
#ex9-12
exec "echo Hello!";

