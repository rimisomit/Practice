#! /usr/bin/perl
#ex9-6
format STDOUT =
@<<<<<<<<<<<@>>>>>>>>>>>
$text1, $text2
.
$text1 = "Hello";
$text2 = "there!";
write;
