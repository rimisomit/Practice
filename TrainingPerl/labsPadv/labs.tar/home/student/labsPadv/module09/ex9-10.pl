#! /usr/bin/perl
#ex9-10

warn;



