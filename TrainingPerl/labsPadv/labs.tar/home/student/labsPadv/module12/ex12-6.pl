#! /usr/bin/perl
#ex12-6
$array =[ ["apples", "oranges"],
	  ["asparaqus", "corn", "peas"],
	  ["ham", "chicken"] ];
print $array->[1][1];
