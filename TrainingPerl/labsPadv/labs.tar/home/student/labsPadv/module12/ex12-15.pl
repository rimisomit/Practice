#! /usr/bin/perl
#ex12-15
for $outerloop (0..4) {
	push @array, [1, 1, 1, 1, 1];
}
print $array[0][0];
