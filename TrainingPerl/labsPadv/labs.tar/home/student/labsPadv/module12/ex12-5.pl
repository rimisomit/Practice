#! /usr/bin/perl
#ex12-5
@array =( ["apples", "oranges"],
	  ["asparagus", "corn", "peas"],
	  ["ham", "chicken"] );
print $array[1][1];
