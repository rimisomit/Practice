#! /usr/bin/perl
#ex12-38
%hash = (
	fruits => ["apples", "oranges"],
	vegetables => ["corn", "peas", "turnips"],
	meat => ["chicken", "ham"],
);

print $hash{fruits}[0];

