#! /usr/bin/perl
#ex12-39
%hash{fruits} = ["apples", "oranges"];
%hash{veqetables} = ["corn", "peas", "turnips"];
%hash{meat} = ["chicken", "ham"];
print $hash{fruits}[0];

