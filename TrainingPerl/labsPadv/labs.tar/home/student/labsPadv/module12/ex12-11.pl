#! /usr/bin/perl
#ex12-11
@array = ( ["apples", "oranges"],
	   ["asparagus", "corn", "peas"],
    	   ["ham", "chicken"] 
);

print $array[0][1], "\n", $array[1][1], "\n", $array[2][1], "\n",;
