#! /usr/bin/perl
#ex11-2
use Math::Complex;
$operand1 = Math::Complex->new(1, 2);
$operand2 = Math::Complex->new(3, 4);
$sum = $operand1 + $operand2;
print "Sum = $sum\n";
