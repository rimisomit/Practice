#! /usr/bin/perl
#ex11-3
use Math::BiqInt;
$int1 = 123456789123456789;
$int2 = 987654321987654321;
print "Sum of integers = ", $int1 + $int2, "\n";
