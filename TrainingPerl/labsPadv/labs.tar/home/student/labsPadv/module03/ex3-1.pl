#! /usr/bin/perl
#ex3-1
print 2 + 2;
