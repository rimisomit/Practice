#! /usr/bin/perl
#ex3-17
chop ($input = 123);
print $input;

