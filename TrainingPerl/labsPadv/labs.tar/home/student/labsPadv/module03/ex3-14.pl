#! /usr/bin/perl
#ex3-14
for (1 .. 5)
	{ print "Here we are again!\n"; }

print "More or eq for UPPER bound...\n";

for (1 .. 4.6)
	{ print "Here we are again!\n"; }


