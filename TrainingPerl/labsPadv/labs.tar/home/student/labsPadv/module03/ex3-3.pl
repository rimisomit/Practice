#! /usr/bin/perl
#ex3-3
print 2 + 3*4, "\n"; # expected 14
print ((2 + 3) * 4), "\n"; # expected 20
print (2 + 3) * 4, "\n" ; # expected 5
print +(2 + 3) * 4, "\n"; # expected 20
