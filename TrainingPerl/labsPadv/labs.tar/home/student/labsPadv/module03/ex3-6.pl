#! /usr/bin/perl
#ex3-6
$variable1 = 1;
$variable2 = 1;

print ++$variable1 . "\n";
print $variable1 . "\n";

print $variable2++ . "\n";
print $variable2 . "\n";

$variable = 'AAA';
print ++$variable . "\n";

$variable = 'bbb';
print ++$variable . "\n";

$variable = 'in';
print ++$variable . "\n";
