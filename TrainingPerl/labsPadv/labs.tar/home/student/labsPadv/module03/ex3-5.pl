#! /usr/bin/perl
#ex3-5
$hash{fruit} = apple;
$hash{sandwich} = hamburger;
$hash{drink} = bubbly;
$hashref = \%hash;
print $hashref->{sandwich};

