#! /usr/bin/perl
#ex3-15
while (<>)
	{ print $_ >= 0 ? $_ :-$_}

