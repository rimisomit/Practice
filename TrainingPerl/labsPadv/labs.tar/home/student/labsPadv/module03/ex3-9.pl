#! /usr/bin/perl
#ex3-9
while (<>) {
if ($_ > 100)
	{ print "Too big!\n"; }
}
