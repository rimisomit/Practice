#! /usr/bin/perl
#ex3-19
print 1, 2, 3, 4, sort 9, 8, 7, 6, 5;

