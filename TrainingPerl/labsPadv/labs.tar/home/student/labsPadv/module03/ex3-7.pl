#! /usr/bin/perl
#ex3-7
$line = ".Hello!";
if ($line =~ m/^\./)
	{ print "Should't start a sentence with a period!"; }
