#! /usr/bin/perl
#ex8-2
while (<>) {
	chop;
	print;
}
