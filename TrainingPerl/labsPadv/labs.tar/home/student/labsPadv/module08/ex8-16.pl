#! /usr/bin/perl
#ex8-16
push @array, 5;
print pop @array;
