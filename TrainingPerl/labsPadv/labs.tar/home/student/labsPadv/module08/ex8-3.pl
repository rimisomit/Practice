#! /usr/bin/perl
#ex8-3
print chr 65;

