#! /usr/bin/perl
#ex8-20
@array = (1, 2, 3);
print scalar @array;
