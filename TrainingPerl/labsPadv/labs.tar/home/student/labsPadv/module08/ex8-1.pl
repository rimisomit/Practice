#! /usr/bin/perl
#ex8-1
while (<>) {
	chomp;
	print;
}
