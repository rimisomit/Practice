#! /usr/bin/perl
#ex8-18
@array = (1, 2, 3);
print join(", ", reverse @array);
