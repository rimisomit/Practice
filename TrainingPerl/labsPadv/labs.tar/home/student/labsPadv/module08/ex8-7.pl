#! /usr/bin/perl
#ex8-7
$_="A";
print hex
