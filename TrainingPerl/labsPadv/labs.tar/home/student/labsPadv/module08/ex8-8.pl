#! /usr/bin/perl
#ex8-8
$text = "Here is the text!";
print index $text, "text";
