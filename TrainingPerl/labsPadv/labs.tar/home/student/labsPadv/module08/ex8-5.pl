#! /usr/bin/perl
#ex8-5
eval {print "Hello print "."there."."\n";};


