#! /usr/bin/perl
#ex8-12
print lcfirst 'HELLO!';
