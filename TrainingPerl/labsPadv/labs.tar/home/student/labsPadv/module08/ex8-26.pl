#! /usr/bin/perl
#ex8-26
@array = (4, 5, 6);
unshift @array, 1, 2, 3;
print join(", ", @array);

