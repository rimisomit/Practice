#! /usr/bin/perl
#ex8-19
$text = "Here is the text!";
print rindex $text, "text";
