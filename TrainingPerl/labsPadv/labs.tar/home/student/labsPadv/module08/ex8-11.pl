#! /usr/bin/perl
#ex8-11
print lc 'HELLO!';
