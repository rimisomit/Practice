#! /usr/bin/perl
#ex8-27
$hash{sandwich} = 'ham and cheese';
$hash{drink} = 'diet cola';
foreach $value (values %hash) {
	print "$value\n"; }


