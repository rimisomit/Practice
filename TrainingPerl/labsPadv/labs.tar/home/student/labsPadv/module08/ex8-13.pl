#! /usr/bin/perl
#ex8-13
$text = "Here is the text.";
	print length $text;

