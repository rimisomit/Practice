#! /usr/bin/perl
#ex8-15
print ord 'A';
