#! /usr/bin/perl
#ex8-17
print rand, "\n", rand, "\n", rand, "\n";
