#! /usr/bin/perl
#ex7-15
print join(",\n", @INC);
