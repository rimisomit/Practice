#! /usr/bin/perl
#ex7-3
@array = (1, 2, 3);
$"=",";
$text = "@array";
print $text;
