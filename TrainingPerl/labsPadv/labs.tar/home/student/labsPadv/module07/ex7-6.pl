#! /usr/bin/perl
#ex7-6
$,=';';
print 1, 2, 3;
