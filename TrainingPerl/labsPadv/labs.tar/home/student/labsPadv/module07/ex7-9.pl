#! /usr/bin/perl
#ex7-9
$\ = "END_OF_OUTPUT" ;
print "Hello!";
