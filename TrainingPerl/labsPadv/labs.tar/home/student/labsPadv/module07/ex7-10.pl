#! /usr/bin/perl
#ex7-10
print $];
