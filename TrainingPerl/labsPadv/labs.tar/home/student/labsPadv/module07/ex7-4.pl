#! /usr/bin/perl
#ex7-4
$pi = 3.14159265359;
$# = '%.6g';
print "$pi\n";
