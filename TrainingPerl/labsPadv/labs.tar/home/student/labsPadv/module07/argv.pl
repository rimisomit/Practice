#! /usr/bin/perl
# AGRV
$text=<>;
print $ARGV;
