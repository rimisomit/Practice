#! /usr/bin/perl
#ex7-7
undef $/;
# open HANDLE, "file.txt";
$text = <DATA>;
print $text;

__DATA__
the text
the text
the text
