#! /usr/bin/perl
#ex7-8
$hash{"1$;1$;1"} = "Hello!";
print $hash{1,1,1};

