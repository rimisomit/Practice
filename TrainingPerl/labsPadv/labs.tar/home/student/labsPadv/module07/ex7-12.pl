#! /usr/bin/perl
#ex7-12
print $^O;

