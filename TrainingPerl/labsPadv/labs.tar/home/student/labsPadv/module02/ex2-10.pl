#! /usr/bin/perl
#ex2-10
push (@array, "one");
push (@array, "two");
push (@array, "three");
print $#array, @array;


