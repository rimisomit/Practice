#! /usr/bin/perl
#ex2-4
@array = (1, 2, 3);
print $array[0]; # expected 1
