#! /usr/bin/perl
#ex2-27
%hash = ( fruit , apple,
	  sandwich , hamburger,
	  drink , bubby );
print "$hash{fruit}\n";


