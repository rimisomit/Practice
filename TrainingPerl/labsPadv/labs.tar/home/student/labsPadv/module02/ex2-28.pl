#! /usr/bin/perl
#ex2-28
%hash = ( fruit => apple,
	  sandwich => hamburger,
	  drink => bubby );
print "$hash{fruit}\n";


