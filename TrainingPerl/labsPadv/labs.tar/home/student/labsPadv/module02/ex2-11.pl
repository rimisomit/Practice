#! /usr/bin/perl
#ex2-11
@array = ("one", "two", "three");
$variable1 = pop(@array);
print "$variable1/$#array";


