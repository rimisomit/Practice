#! /usr/bin/perl
#ex2-9
@array = ("one", "two", "three");
for ($index = 0; $index <= $#array; $index++) {
	print $array[$index], "	";}


