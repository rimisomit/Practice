#! /usr/bin/perl
#ex2-13
@array = (1, 2, 3);
$arr_length = $#array + 1;
print "\@array " , " $arr_length " , " elements. ";

