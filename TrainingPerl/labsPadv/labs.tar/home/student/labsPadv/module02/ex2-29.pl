#! /usr/bin/perl
#ex2-29
$hash2{cake} = chocolate;
$hash2{pie} = blueberry;
$hash2{'ice cream'} = pecan;
print "$hash2{'ice cream'}\n";


