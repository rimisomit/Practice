#! /usr/bin/perl -w
#ex2-18
@array = (1, 2, 3, 4, 5);
foreach $element (@array) {
	print "$element\n";
}
