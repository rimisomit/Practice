#! /usr/bin/perl -w
##ex2-44
$variable = 5;
print ${*variable{SCALAR}};
