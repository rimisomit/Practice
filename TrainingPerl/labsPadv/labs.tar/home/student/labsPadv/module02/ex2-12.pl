#! /usr/bin/perl
##ex2-12
@array = ("one", "two", "three");
$variable1 = shift (@array);
print "$variable1/$#array";



