#! /usr/bin/perl -w
#ex2-14
@array = (1, 2, 3);
$variable = @array;
print "\@array has $variable elements.";
