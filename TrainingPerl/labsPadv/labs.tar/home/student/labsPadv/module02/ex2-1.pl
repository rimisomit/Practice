#! /usr/bin/perl
#ex2-1
@array = (1, 2, 3);
print $array[0];
