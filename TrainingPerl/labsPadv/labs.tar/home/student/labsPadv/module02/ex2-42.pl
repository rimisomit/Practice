#! /usr/bin/perl
#ex2-42
($var1,$var2,@array) = (1, 2, 3, 4, 5, 6, 7, 8);
print "$var1\n";
print "$var2\n";
print "@array\n";



