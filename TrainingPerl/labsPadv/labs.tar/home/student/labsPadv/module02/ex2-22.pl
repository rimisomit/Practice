#! /usr/bin/perl -w
#ex2-22
@array = ("one", "two", "three");
foreach $element (@array) {
	print "Current element = $element\n";
}

