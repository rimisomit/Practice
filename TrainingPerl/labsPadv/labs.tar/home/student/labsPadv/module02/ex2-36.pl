#! /usr/bin/perl
#ex2-36
$hash{fruit} = apple;
$hash{sandwich} = hamburger;
$hash{drink} = bubbly;
print "${@[%hash]}\n";

