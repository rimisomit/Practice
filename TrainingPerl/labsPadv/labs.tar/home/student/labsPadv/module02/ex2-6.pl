#! /usr/bin/perl
#ex2-6
@array = ("one", "two", "three",
		"four", "five", "six");
print @array;


