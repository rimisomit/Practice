#! /usr/bin/perl
#ex2-26
%hash = ();
$hash{fruit} = apple;
$hash{sandwich} = hamburger;
$hash{drink} = bubbly;
print $hash{sandwich};


