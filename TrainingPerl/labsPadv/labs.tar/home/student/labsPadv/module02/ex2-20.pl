#! /usr/bin/perl -w
#ex2-20
@array = ("one", "two", "three");
$, = ",";
print "Here is the array: @array.\n";

