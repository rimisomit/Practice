#! /usr/bin/perl
#ex2-7
@array = ("one", "two", "three");
print $array[1];


