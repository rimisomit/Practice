#! /usr/bin/perl
#ex2-5
@array = ("one", "two", "three");
print @array;

